// const people = [
//   { name: 'Nader', age: 36 },
//   { name: 'Amanda', age: 24 },
//   { name: 'Jason', age: 44 }
// ]

const appstore = [
  { name: 'Whatsapp', url: 'https://itunes.apple.com/in/app/whatsapp-messenger/id310633997?mt=8', store: 'Apple Store', imgname: 'https://facebook.github.io/react-native/docs/assets/favicon.png' },
  { name: 'Facebook', url: 'https://itunes.apple.com/in/app/facebook/id284882215?mt=8', store: 'Apple Store', imgname: 'https://facebook.github.io/react-native/docs/assets/favicon.png' },
  { name: 'Instagram', url: 'https://itunes.apple.com/in/app/instagram/id389801252?mt=8', store: 'Apple Store', imgname: 'https://facebook.github.io/react-native/docs/assets/favicon.png' },
  { name: 'Paytm', url: 'https://itunes.apple.com/in/app/paytm-payments-bank-account/id473941634?mt=8', store: 'Apple Store', imgname: 'https://facebook.github.io/react-native/docs/assets/favicon.png' },
  { name: 'Olacabs', url: 'https://play.google.com/store/apps/details?id=com.olacabs.customer', store: 'Play Store', imgname: 'https://facebook.github.io/react-native/docs/assets/favicon.png' },
  { name: 'Hotstar', url: 'https://play.google.com/store/apps/details?id=in.startv.hotstar', store: 'Play Store', imgname: 'https://facebook.github.io/react-native/docs/assets/favicon.png' },
  { name: 'Subwaysurf', url: 'https://play.google.com/store/apps/details?id=com.kiloo.subwaysurf', store: 'Play Store', imgname: 'https://facebook.github.io/react-native/docs/assets/favicon.png' }

]





export default () => {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      return resolve(appstore)
    }, 3000)
  })
}