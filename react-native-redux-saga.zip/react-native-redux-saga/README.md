# Example React Native Applications using Redux

## To run this project:

1. download project   
`
git clone git@github.com:react-native-training/react-native-redux-saga-example.git
`

2. move into directory   
`
cd react-native-redux-saga-example
`

3. install dependencies   
`
yarn
`

4. run packager   
`
npm start
`

5. run on device   
`
react-native run-ios
`